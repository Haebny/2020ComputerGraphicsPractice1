////////////////////////////////////////////////////////////////////////////////
// Filename: graphicsclass.h
////////////////////////////////////////////////////////////////////////////////
#ifndef _GRAPHICSCLASS_H_
#define _GRAPHICSCLASS_H_


///////////////////////
// MY CLASS INCLUDES //
///////////////////////
#include "inputclass.h"
#include "d3dclass.h"
#include "cameraclass.h"
#include "modelclass.h"
#include "lightclass.h"
#include "lightshaderclass.h"
#include "lightshaderclass2.h"
#include "rendertextureclass.h"
#include "depthshaderclass.h"
#include "shadowshaderclass.h"
#include "textclass.h"
#include "soundclass.h"

#include <vector>

/////////////
// GLOBALS //
/////////////
const bool FULL_SCREEN = true;
const bool VSYNC_ENABLED = true;
const float SCREEN_DEPTH = 1000.0f;  
const float SCREEN_NEAR = 1.0f;   
const int SHADOWMAP_WIDTH = 4096;
const int SHADOWMAP_HEIGHT = 4096;


////////////////////////////////////////////////////////////////////////////////
// Class name: GraphicsClass
////////////////////////////////////////////////////////////////////////////////
class GraphicsClass
{
public:
	enum Tags
	{
		NONE,
		LP,
		FINDOBJ
	};

	struct Model
	{
		ModelClass* model;
		char* objpath;
		WCHAR* texturepath;

		bool isMoving;
		D3DXVECTOR3 pos;
		int tag;
		char* name;
	};

public:
	GraphicsClass();
	GraphicsClass(const GraphicsClass&);
	~GraphicsClass();

	bool Initialize(HINSTANCE, HWND, int, int);
	void Shutdown();
	bool Frame(int, int, int, int, float, HWND); // mouseX, mouseY, fps, cpu, frameTime

	// ī�޶� �����̱�
	void MoveForward();
	void MoveBack();
	void MoveLeft();
	void MoveRight();
	void ApplyBoundary();

	bool HandleInput();
	bool RaySphereIntersect(D3DXVECTOR3, D3DXVECTOR3, float);
	void TestIntersection(int, int);

	int polygon_num;

private:
	bool Render(float);
	bool RenderSceneToTexture();
	bool RenderSceneToTexture2();
	bool RenderSceneToTexture3();
	bool RenderSceneToTexture4();
	bool RenderSceneToTexture5();


private:
	int m_key;
	InputClass* m_Input;
	D3DClass* m_D3D;
	CameraClass* m_Camera;
	HWND m_hwnd;

	vector<Model*> m_Models;
	Model floor, wall, barbottom, bartop,
		diningset, windows, shelves, wallshelf, holder,
		barrels, door, bottles, corks, wineglasses,
		screen, lights, fan, plane, album;

	LightClass* m_Light;
	RenderTextureClass* m_RenderTexture;
	DepthShaderClass* m_DepthShader;
	ShadowShaderClass* m_ShadowShader;
	LightClass* m_Light2;
	LightClass* m_Light3;
	LightClass* m_Light4;
	LightClass* m_Light5;
	RenderTextureClass* m_RenderTexture2;
	RenderTextureClass* m_RenderTexture3;
	RenderTextureClass* m_RenderTexture4;
	RenderTextureClass* m_RenderTexture5;
	TextClass* m_Text;
	SoundClass* m_Sound;

	LightShaderClass* m_LightShader;
	LightShaderClass2* m_LightShader2;
	LightClass* g_Light1;
	LightClass* g_Light2;
	LightClass* g_Light3;
	LightClass* g_Light4;
	LightClass* g_Light5;
	LightClass* g_Light6;
	LightClass* g_Light7;
	LightClass* g_Light8;

	bool mode1, mode2;

	// Ű���� �ߺ��Է� ����
	bool isKeyDown;

	// ���콺 ��ŷ
	bool m_beginCheck;
	int m_screenWidth, m_screenHeight;

	// �÷��̾��� ������ ����
	D3DXVECTOR3 FixedHeight;
	bool isBar;

	// ī�޶� ����
	D3DXVECTOR3 CamPos, CamRot;
	float speed = 2.0f;
	float PreX, PreY;
};

#endif