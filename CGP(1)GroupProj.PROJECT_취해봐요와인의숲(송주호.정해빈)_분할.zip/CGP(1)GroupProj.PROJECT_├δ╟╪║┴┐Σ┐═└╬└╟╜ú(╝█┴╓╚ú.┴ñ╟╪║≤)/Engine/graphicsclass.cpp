////////////////////////////////////////////////////////////////////////////////
// Filename: graphicsclass.cpp
////////////////////////////////////////////////////////////////////////////////
#include "graphicsclass.h"


GraphicsClass::GraphicsClass()
{
	m_Input = 0;
	m_D3D = 0;
	m_Camera = 0;
	//m_CubeModel = 0;
	//m_GroundModel = 0;
	//m_SphereModel = 0;
	//m_TextureShader = 0;
	m_Light = 0;
	m_RenderTexture = 0;
	m_DepthShader = 0;	
	m_ShadowShader = 0;
	m_Light2 = 0;
	m_Light3 = 0;
	m_Light4 = 0;
	m_Light5 = 0;
	m_RenderTexture2 = 0;
	m_RenderTexture3 = 0;
	m_RenderTexture4 = 0;
	m_RenderTexture5 = 0;
	m_Sound = 0;
	m_Text = 0;
	
	polygon_num = 0;

	mode1 = true;
	mode2 = true;

	g_Light1 = 0;
	g_Light2 = 0;
	g_Light3 = 0;
	g_Light4 = 0;
	g_Light5 = 0;
	g_Light6 = 0;
	g_Light7 = 0;
	g_Light8 = 0;

	// Ű���� �ߺ��Է� ����
	isKeyDown = false;

#pragma region ������Ʈ �� �ؽ��� ��� ����
	floor.objpath = "../Engine/data/objects/floor.obj";
	floor.texturepath = L"../Engine/data/textures/floor.dds";
	floor.tag = NONE;
	floor.name = "floor";
	floor.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	wall.objpath = "../Engine/data/objects/wall.obj";
	wall.texturepath = L"../Engine/data/textures/wall.dds";
	wall.tag = NONE;
	wall.name = "wall";
	wall.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	barbottom.objpath = "../Engine/data/objects/barbottom.obj";
	barbottom.texturepath = L"../Engine/data/textures/marble.dds";
	barbottom.tag = NONE;
	barbottom.name = "barbottom";
	barbottom.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	bartop.objpath = "../Engine/data/objects/bartop.obj";
	bartop.texturepath = L"../Engine/data/textures/bmarble.dds";
	bartop.tag = NONE;
	bartop.name = "bartop";
	bartop.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	windows.objpath = "../Engine/data/objects/windows.obj";
	windows.texturepath = L"../Engine/data/textures/wood.dds";
	windows.tag = NONE;
	windows.name = "windows";
	windows.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	diningset.objpath = "../Engine/data/objects/diningset.obj";
	diningset.texturepath = L"../Engine/data/textures/dining.dds";
	diningset.tag = NONE;
	diningset.name = "diningset";
	diningset.pos = D3DXVECTOR3(39.076f, -38.66f, -123.145f);

	shelves.objpath = "../Engine/data/objects/shelves.obj";
	shelves.texturepath = L"../Engine/data/textures/shelf.dds";
	shelves.tag = NONE;
	shelves.name = "shleves";
	shelves.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	wallshelf.objpath = "../Engine/data/objects/wallshelf.obj";
	wallshelf.texturepath = windows.texturepath;
	wallshelf.tag = NONE;
	wallshelf.name = "wallshelf";
	wallshelf.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	holder.objpath = "../Engine/data/objects/holder.obj";
	holder.texturepath = L"../Engine/data/textures/lightwood.dds";
	holder.tag = NONE;
	holder.name = "holder";
	holder.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	barrels.objpath = "../Engine/data/objects/barrels.obj";
	barrels.texturepath = L"../Engine/data/textures/barrel.dds";
	barrels.tag = NONE;
	barrels.name = "barrels";
	barrels.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	door.objpath = "../Engine/data/objects/door.obj";
	door.texturepath = L"../Engine/data/textures/shelf.dds";
	door.tag = NONE;
	door.name = "door";
	door.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	bottles.objpath = "../Engine/data/objects/bottles.obj";
	bottles.texturepath = L"../Engine/data/textures/purple.dds";;
	bottles.tag = NONE;
	bottles.name = "bottle";
	bottles.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	corks.objpath = "../Engine/data/objects/corks.obj";
	corks.texturepath = L"../Engine/data/textures/cork.dds";
	corks.tag = NONE;
	corks.name = "cork";
	corks.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	wineglasses.objpath = "../Engine/data/objects/wineglass.obj";
	wineglasses.texturepath = L"../Engine/data/textures/glass.dds";
	wineglasses.tag = NONE;
	wineglasses.name = "wineglass";
	wineglasses.pos = D3DXVECTOR3(-94.803f, 19.809f, -198.604f);

	screen.objpath = "../Engine/data/objects/screen.obj";
	screen.texturepath = L"../Engine/data/textures/night.dds";
	screen.tag = NONE;
	screen.name = "screen";
	screen.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	lights.objpath = "../Engine/data/objects/lights.obj";
	lights.texturepath = L"../Engine/data/textures/marble.dds";
	lights.tag = NONE;
	lights.name = "lights";
	lights.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	fan.objpath = "../Engine/data/objects/fan.obj";
	fan.texturepath = L"../Engine/data/textures/lightwood.dds";
	fan.tag = NONE;
	fan.name = "fan";
	fan.pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	plane.objpath = "../Engine/data/objects/plane.obj";
	plane.texturepath = L"../Engine/data/textures/marble.dds";
	plane.tag = FINDOBJ;
	plane.name = "plane";
	plane.pos = D3DXVECTOR3(-1038.503f, 40.596f, -438.448f);

	album.objpath = "../Engine/data/objects/album.obj";
	album.texturepath = L"../Engine/data/textures/kk.dds";
	album.tag = FINDOBJ;
	album.name = "album";
	album.pos = D3DXVECTOR3(-920.53f, -27.37f, 76.01f);

#pragma endregion

#pragma region �÷��̾� �̵����� ����
	FixedHeight.y = 5.0f;	// ���� ����
	isBar = true;
#pragma endregion

	// ī�޶� �ʱ�ȭ
	CamPos.x = 0.0f;
	CamPos.y = 0.0f;
	CamPos.z = 0.0f;

	CamRot.x = 0.0f;
	CamRot.y = 0.0f;
	CamRot.z = 0.0f;

	PreX = 0.0f;
	PreY = 0.0f;
}


GraphicsClass::GraphicsClass(const GraphicsClass& other)
{
}


GraphicsClass::~GraphicsClass()
{
}


bool GraphicsClass::Initialize(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight)
{
	bool result;
	D3DXMATRIX baseViewMatrix;

	// Store the screen width and height for MOUSE PICKING
	m_screenWidth = screenWidth;
	m_screenHeight = screenHeight;

	// Create the input object.  This object will be used to handle reading the keyboard input from the user.
	m_Input = new InputClass;
	if (!m_Input)
	{
		return false;
	}

	// Initialize the input object.
	result = m_Input->Initialize(hinstance, hwnd, screenWidth, screenHeight);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the input object.", L"Error", MB_OK);
		return false;
	}

	// Create the Direct3D object.
	m_D3D = new D3DClass;
	if(!m_D3D)
	{
		return false;
	}

	// Initialize the Direct3D object.
	result = m_D3D->Initialize(screenWidth, screenHeight, VSYNC_ENABLED, hwnd, FULL_SCREEN, SCREEN_DEPTH, SCREEN_NEAR);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize Direct3D.", L"Error", MB_OK);
		return false;
	}

	// Create the camera object.
	m_Camera = new CameraClass;
	if(!m_Camera)
	{
		return false;
	}

	// Initialize a base view matrix with the camera for 2D user interface rendering. 
	m_Camera->SetPosition(0.0f, 1.0f, -15.0f);
	m_Camera->Render();
	m_Camera->GetViewMatrix(baseViewMatrix);

#pragma region �� ���Ϳ� �� �߰��ϱ�
	m_Models.push_back(&floor);
	m_Models.push_back(&wall);
	m_Models.push_back(&barbottom);
	m_Models.push_back(&bartop);
	m_Models.push_back(&diningset);
	m_Models.push_back(&windows);
	m_Models.push_back(&shelves);
	m_Models.push_back(&wallshelf);
	m_Models.push_back(&holder);
	m_Models.push_back(&barrels);
	m_Models.push_back(&door);
	m_Models.push_back(&bottles);
	m_Models.push_back(&corks);
	m_Models.push_back(&wineglasses);
	m_Models.push_back(&screen);
	m_Models.push_back(&lights);
	m_Models.push_back(&fan);
	m_Models.push_back(&plane);
	m_Models.push_back(&album);
#pragma endregion

	


	for (int i = 0; i < m_Models.size(); i++)
	{
		// Create the model objects
		m_Models.at(i)->model = new ModelClass();

		if (!m_Models.at(i)->model)
		{
			MessageBox(hwnd, L"Could not create the model object.", L"Error", MB_OK);
			return false;
		}

		// ���콺 Ŭ�� ���� ����
		m_Models.at(i)->isMoving = false;

		m_Models.at(i)->model->Initialize(m_D3D->GetDevice(), m_Models.at(i)->objpath, m_Models.at(i)->texturepath);
		if (!result)
		{
			MessageBox(hwnd, L"Could not initialize the model object.", L"Error", MB_OK);
			return false;
		}

		polygon_num += m_Models.at(i)->model->polygon_num;
	}

	m_Text = new TextClass;
	if (!m_Text)
	{
		return false;
	}
	result = m_Text->Initialize(m_D3D->GetDevice(), m_D3D->GetDeviceContext(), hwnd, screenWidth, screenHeight, baseViewMatrix);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the text object.", L"Error", MB_OK);
		return false;
	}
	// Set the initial position of the camera.
	m_Camera->SetPosition(0.0f, 0.0f, -10.0f);

	// Create the light object.
	m_Light = new LightClass;
	if(!m_Light)
	{
		return false;
	}

	// Initialize the light object.
	m_Light->SetAmbientColor(0.15f, 0.15f, 0.15f, 1.0f);
	m_Light->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light->SetDirection(0.0f, -1.0f, 1.0f);
	m_Light->SetSpecularColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light->SetSpecularPower(6.0f);
	m_Light->SetLookAt(82.259f,-1.0f, -197.447f);
	m_Light->GenerateProjectionMatrix(SCREEN_DEPTH, SCREEN_NEAR);
	

	
	// Create the render to texture object.
	m_RenderTexture = new RenderTextureClass;
	if(!m_RenderTexture)
	{
		return false;
	}

	// Initialize the render to texture object.
	result = m_RenderTexture->Initialize(m_D3D->GetDevice(), SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, SCREEN_DEPTH, SCREEN_NEAR);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the render to texture object.", L"Error", MB_OK);
		return false;
	}

	// Create the depth shader object.
	m_DepthShader = new DepthShaderClass;
	if(!m_DepthShader)
	{
		return false;
	}

	// Initialize the depth shader object.
	result = m_DepthShader->Initialize(m_D3D->GetDevice(), hwnd);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the depth shader object.", L"Error", MB_OK);
		return false;
	}

	// Create the shadow shader object.
	m_ShadowShader = new ShadowShaderClass;
	if(!m_ShadowShader)
	{
		return false;
	}

	// Initialize the shadow shader object.
	result = m_ShadowShader->Initialize(m_D3D->GetDevice(), hwnd);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the shadow shader object.", L"Error", MB_OK);
		return false;
	}

	// Create the second light object.
	m_Light2 = new LightClass;
	if(!m_Light2)
	{
		return false;
	}

	// Initialize the second light object.
	m_Light2->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light2->SetLookAt(-46.924f, -1.0f, -350.724f);
	m_Light2->GenerateProjectionMatrix(SCREEN_DEPTH, SCREEN_NEAR);

	// Create the second render to texture object.
	m_RenderTexture2 = new RenderTextureClass;
	if(!m_RenderTexture2)
	{
		return false;
	}

	// Initialize the second render to texture object.
	result = m_RenderTexture2->Initialize(m_D3D->GetDevice(), SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, SCREEN_DEPTH, SCREEN_NEAR);
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the second render to texture object.", L"Error", MB_OK);
		return false;
	}

	m_Light3 = new LightClass;
	if (!m_Light3)
	{
		return false;
	}

	// Initialize the second light object.
	m_Light3->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light3->SetLookAt(82.259f, -1.0f, -47.281f);
	m_Light3->GenerateProjectionMatrix(SCREEN_DEPTH, SCREEN_NEAR);

	// Create the second render to texture object.
	m_RenderTexture3 = new RenderTextureClass;
	if (!m_RenderTexture3)
	{
		return false;
	}

	// Initialize the second render to texture object.
	result = m_RenderTexture3->Initialize(m_D3D->GetDevice(), SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, SCREEN_DEPTH, SCREEN_NEAR);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the second render to texture object.", L"Error", MB_OK);
		return false;
	}

	m_Light4 = new LightClass;
	if (!m_Light4)
	{
		return false;
	}

	// Initialize the second light object.
	m_Light4->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light4->SetLookAt(-636.0f, -1.0f, -282.0f);
	m_Light4->GenerateProjectionMatrix(SCREEN_DEPTH, SCREEN_NEAR);

	// Create the second render to texture object.
	m_RenderTexture4 = new RenderTextureClass;
	if (!m_RenderTexture4)
	{
		return false;
	}

	// Initialize the second render to texture object.
	result = m_RenderTexture4->Initialize(m_D3D->GetDevice(), SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, SCREEN_DEPTH, SCREEN_NEAR);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the second render to texture object.", L"Error", MB_OK);
		return false;
	}

	m_Light5 = new LightClass;
	if (!m_Light5)
	{
		return false;
	}

	// Initialize the second light object.
	m_Light5->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Light5->SetLookAt(-950.0f, -1.0f, -282.0f);
	m_Light5->GenerateProjectionMatrix(SCREEN_DEPTH, SCREEN_NEAR);

	// Create the second render to texture object.
	m_RenderTexture5 = new RenderTextureClass;
	if (!m_RenderTexture5)
	{
		return false;
	}

	// Initialize the second render to texture object.
	result = m_RenderTexture5->Initialize(m_D3D->GetDevice(), SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, SCREEN_DEPTH, SCREEN_NEAR);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the second render to texture object.", L"Error", MB_OK);
		return false;
	}

	m_Sound = new SoundClass;
	if (!m_Sound)
	{
		return false;
	}
	// Initialize the sound object.

	result = m_Sound->Initialize(hwnd);
	if (!result)
	{
		MessageBox(m_hwnd, L"Could not initialize Direct Sound.", L"Error", MB_OK);
		return false;
	}
	//////////////////////////////
	m_LightShader = new LightShaderClass;
	if (!m_LightShader)
	{
		return false;
	}

	result = m_LightShader->Initialize(m_D3D->GetDevice(), hwnd);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the light shader object.", L"Error", MB_OK);
		return false; 
	}

	m_LightShader2 = new LightShaderClass2;
	if (!m_LightShader)
	{
		return false;
	}

	result = m_LightShader2->Initialize(m_D3D->GetDevice(), hwnd);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the light shader object.", L"Error", MB_OK);
		return false;
	}

	g_Light1 = new LightClass; if (!g_Light1) 
	{ 
		return false; 
	} // Initialize the first light object. 

	g_Light1->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f); 
	g_Light1->SetPosition2(82.259f, 87.791f, -122.281f);

	g_Light2 = new LightClass; if (!g_Light2)
	{
		return false;
	} // Initialize the first light object. 

	g_Light2->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light2->SetPosition2(82.259f, 87.791f, 0.281f);

	g_Light3 = new LightClass; if (!g_Light3)
	{
		return false;
	} // Initialize the first light object. 

	g_Light3->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light3->SetPosition2(80.259f, 37.791f, -239.281f);

	g_Light4 = new LightClass; if (!g_Light4)
	{
		return false;
	} // Initialize the first light object. 

	g_Light4->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light4->SetPosition2(60.259f, 87.791f, -47.281f);

	////////

	g_Light5 = new LightClass; if (!g_Light5)
	{
		return false;
	} // Initialize the first light object. 

	g_Light5->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light5->SetPosition2(100.259f, 87.791f, -47.281f);

	g_Light6 = new LightClass; if (!g_Light6)
	{
		return false;
	} // Initialize the first light object. 

	g_Light6->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light6->SetPosition2(60.259f, 87.791f, -197.447f);

	g_Light7 = new LightClass; if (!g_Light7)
	{
		return false;
	} // Initialize the first light object. 

	g_Light7->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light7->SetPosition2(-3.0f, 0.0f, -3.0f);

	g_Light7 = new LightClass; if (!g_Light7)
	{
		return false;
	} // Initialize the first light object. 

	g_Light7->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light7->SetPosition2(100.259f, 107.791f, -197.447f);

	g_Light8 = new LightClass; if (!g_Light8)
	{
		return false;
	} // Initialize the first light object. 

	g_Light8->SetDiffuseColor(1.0f, 1.0f, 1.0f, 1.0f);
	g_Light8->SetPosition2(0.0f, 0.0f, 0.0f);



	return true;
}


void GraphicsClass::Shutdown()
{
	if (m_Text) {
		m_Text->Shutdown();
		delete m_Text;
		m_Text = 0;
	}
	// Release the second render to texture object.
	if(m_RenderTexture2)
	{
		m_RenderTexture2->Shutdown();
		delete m_RenderTexture2;
		m_RenderTexture2 = 0;
	}
	if (m_RenderTexture3)
	{
		m_RenderTexture3->Shutdown();
		delete m_RenderTexture3;
		m_RenderTexture3 = 0;
	}
	if (m_RenderTexture4)
	{
		m_RenderTexture4->Shutdown();
		delete m_RenderTexture4;
		m_RenderTexture4 = 0;
	}
	if (m_RenderTexture5)
	{
		m_RenderTexture5->Shutdown();
		delete m_RenderTexture5;
		m_RenderTexture5 = 0;
	}

	// Release the second light object.
	if(m_Light2)
	{
		delete m_Light2;
		m_Light2 = 0;
	}
	if (m_Light3)
	{
		delete m_Light3;
		m_Light3 = 0;
	}
	if (m_Light4)
	{
		delete m_Light4;
		m_Light4 = 0;
	}
	if (m_Light5)
	{
		delete m_Light5;
		m_Light5 = 0;
	}
	////
	if (g_Light1)
	{
		delete g_Light1;
		g_Light1 = 0;
	}
	if (g_Light2)
	{
		delete g_Light2;
		g_Light2 = 0;
	}
	if (g_Light3)
	{
		delete g_Light3;
		g_Light3 = 0;
	}
	if (g_Light4)
	{
		delete g_Light4;
		g_Light4 = 0;
	}
	if (g_Light5)
	{
		delete g_Light5;
		g_Light5 = 0;
	}
	if (g_Light6)
	{
		delete g_Light6;
		g_Light6 = 0;
	}
	if (g_Light7)
	{
		delete g_Light7;
		g_Light7 = 0;
	}
	if (g_Light8)
	{
		delete g_Light8;
		g_Light8 = 0;
	}
	if (m_LightShader) 
	{ 
		m_LightShader->Shutdown(); 
		delete m_LightShader; 
		m_LightShader = 0; 
	}

	if (m_LightShader2)
	{
		m_LightShader2->Shutdown();
		delete m_LightShader2;
		m_LightShader2 = 0;
	}

	////

	// Release the shadow shader object.
	if(m_ShadowShader)
	{
		m_ShadowShader->Shutdown();
		delete m_ShadowShader;
		m_ShadowShader = 0;
	}

	// Release the depth shader object.
	if(m_DepthShader)
	{
		m_DepthShader->Shutdown();
		delete m_DepthShader;
		m_DepthShader = 0;
	}

	// Release the render to texture object.
	if(m_RenderTexture)
	{
		m_RenderTexture->Shutdown();
		delete m_RenderTexture;
		m_RenderTexture = 0;
	}

	// Release the light object.
	if(m_Light)
	{
		delete m_Light;
		m_Light = 0;
	}

	// Release the camera object.
	if(m_Camera)
	{
		delete m_Camera;
		m_Camera = 0;
	}

	// Release the D3D object.
	if(m_D3D)
	{
		m_D3D->Shutdown();
		delete m_D3D;
		m_D3D = 0;
	}

	if (m_Sound)
	{
		m_Sound->Shutdown();
		delete m_Sound;
		m_Sound = 0;
	}

	return;
}


bool GraphicsClass::Frame(int mouseX, int mouseY, int fps, int cpu, float frameTime, HWND m_hwnd1)
{
	bool result;

	// Get the location of the mouse from the input object,
	m_Input->GetMouseLocation(mouseX, mouseY);

	m_hwnd = m_hwnd1;
	//  ���� �̵�
	CamRot.y -= (PreX - mouseX) * 0.1f;
	CamRot.x -= (PreY - mouseY) * 0.1f;

	PreX = (float)mouseX;
	PreY = (float)mouseY;

	// Set the position of the camera.
	m_Camera->SetPosition(CamPos.x, CamPos.y, CamPos.z);
	m_Camera->SetRotation(CamRot.x, CamRot.y, CamRot.z);

	// Set the frames per second.
	result = m_Text->SetFps(fps, m_D3D->GetDeviceContext());
	if (!result)
	{
		return false;
	}

	// Set the cpu usage.
	result = m_Text->SetCpu(cpu, m_D3D->GetDeviceContext());
	if (!result)
	{
		return false;
	}
	result = m_Text->SetPolygonts_num(polygon_num, m_D3D->GetDeviceContext());

	// Set the position of the first light.
	m_Light->SetPosition(82.259f, 44.0f, -197.447f);

	// Set the position of the second light.
	m_Light2->SetPosition(-46.924f, 80.855f, -322.724f);
	m_Light3->SetPosition(82.259f, 44.0f, -47.281f);
	m_Light4->SetPosition(-636.0f, 71.0f, -282.0f);
	m_Light5->SetPosition(-950.0f, 80.0f, -282.0f);

	
	result = m_Text->SetPosition(m_Camera->m_positionX, m_D3D->GetDeviceContext());
	result = m_Text->FineList(m_D3D->GetDeviceContext());
	result = m_Text->ObjNum(m_Models.size(), m_D3D->GetDeviceContext());
	result = m_Text->WindowSize(m_D3D->GetDeviceContext());
	static float rotation = 0.0f;

	// Update the rotation variable each frame.
	rotation += (float)D3DX_PI * 0.05f;
	if (rotation > 360.0f)
	{
		rotation -= 360.0f;
	}

	// Handle the input processing.
	result = HandleInput();
	if (!result)
	{
		return false;
	}

	// Render the graphics scene.
	result = Render(rotation);
	if (!result)
	{
		return false;
	}

	return true;
}


bool GraphicsClass::RenderSceneToTexture()
{
	D3DXMATRIX worldMatrix, lightViewMatrix, lightProjectionMatrix, translateMatrix;
	float posX, posY, posZ;
	bool result;


	// Set the render target to be the render to texture.
	m_RenderTexture->SetRenderTarget(m_D3D->GetDeviceContext());

	// Clear the render to texture.
	m_RenderTexture->ClearRenderTarget(m_D3D->GetDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the light view matrix based on the light's position.
	m_Light->GenerateViewMatrix();

	// Get the world matrix from the d3d object.
	m_D3D->GetWorldMatrix(worldMatrix);

	// Get the view and orthographic matrices from the light object.
	m_Light->GetViewMatrix(lightViewMatrix);
	m_Light->GetProjectionMatrix(lightProjectionMatrix);

	D3DXVECTOR3 position;
	// Setup the translation matrix for the cube model.
	for (int i = 0; i < m_Models.size(); i++)
	{
		m_D3D->GetWorldMatrix(worldMatrix);

		position = m_Models.at(i)->pos;
		D3DXMatrixTranslation(&worldMatrix, position.x, position.y, position.z);

		m_Models.at(i)->model->Render(m_D3D->GetDeviceContext());
		result = m_DepthShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
		if (!result)
		{
			return false;
		}
	}

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	m_D3D->SetBackBufferRenderTarget();

	// Reset the viewport back to the original.
	m_D3D->ResetViewport();

	return true;
}


bool GraphicsClass::RenderSceneToTexture2()
{
	D3DXMATRIX worldMatrix, lightViewMatrix, lightProjectionMatrix, translateMatrix;
	float posX, posY, posZ;
	bool result = false;


	// Set the render target to be the render to texture.
	m_RenderTexture2->SetRenderTarget(m_D3D->GetDeviceContext());

	// Clear the render to texture.
	m_RenderTexture2->ClearRenderTarget(m_D3D->GetDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the light view matrix based on the light's position.
	m_Light2->GenerateViewMatrix();

	// Get the world matrix from the d3d object.
	m_D3D->GetWorldMatrix(worldMatrix);

	// Get the view and orthographic matrices from the light object.
	m_Light2->GetViewMatrix(lightViewMatrix);
	m_Light2->GetProjectionMatrix(lightProjectionMatrix);

	D3DXVECTOR3 position;
	// Setup the translation matrix for the cube model.
	for (int i = 0; i < m_Models.size(); i++)
	{
		m_D3D->GetWorldMatrix(worldMatrix);

		position = m_Models.at(i)->pos;
		D3DXMatrixTranslation(&worldMatrix, position.x, position.y, position.z);

		m_Models.at(i)->model->Render(m_D3D->GetDeviceContext());
		result = m_DepthShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
		if (!result)
		{
			return false;
		}
	}

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	m_D3D->SetBackBufferRenderTarget();

	// Reset the viewport back to the original.
	m_D3D->ResetViewport();

	return true;
}

bool GraphicsClass::RenderSceneToTexture3()
{
	D3DXMATRIX worldMatrix, lightViewMatrix, lightProjectionMatrix, translateMatrix;
	float posX, posY, posZ;
	bool result = false;


	// Set the render target to be the render to texture.
	m_RenderTexture3->SetRenderTarget(m_D3D->GetDeviceContext());

	// Clear the render to texture.
	m_RenderTexture3->ClearRenderTarget(m_D3D->GetDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the light view matrix based on the light's position.
	m_Light3->GenerateViewMatrix();

	// Get the world matrix from the d3d object.
	m_D3D->GetWorldMatrix(worldMatrix);

	// Get the view and orthographic matrices from the light object.
	m_Light3->GetViewMatrix(lightViewMatrix);
	m_Light3->GetProjectionMatrix(lightProjectionMatrix);

	D3DXVECTOR3 position;
	// Setup the translation matrix for the cube model.
	for (int i = 0; i < m_Models.size(); i++)
	{
		m_D3D->GetWorldMatrix(worldMatrix);

		position = m_Models.at(i)->pos;
		D3DXMatrixTranslation(&worldMatrix, position.x, position.y, position.z);

		m_Models.at(i)->model->Render(m_D3D->GetDeviceContext());
		result = m_DepthShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
		if (!result)
		{
			return false;
		}
	}

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	m_D3D->SetBackBufferRenderTarget();

	// Reset the viewport back to the original.
	m_D3D->ResetViewport();

	return true;
}

bool GraphicsClass::RenderSceneToTexture4()
{
	D3DXMATRIX worldMatrix, lightViewMatrix, lightProjectionMatrix, translateMatrix;
	float posX, posY, posZ;
	bool result = false;


	// Set the render target to be the render to texture.
	m_RenderTexture4->SetRenderTarget(m_D3D->GetDeviceContext());

	// Clear the render to texture.
	m_RenderTexture4->ClearRenderTarget(m_D3D->GetDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the light view matrix based on the light's position.
	m_Light4->GenerateViewMatrix();

	// Get the world matrix from the d3d object.
	m_D3D->GetWorldMatrix(worldMatrix);

	// Get the view and orthographic matrices from the light object.
	m_Light4->GetViewMatrix(lightViewMatrix);
	m_Light4->GetProjectionMatrix(lightProjectionMatrix);

	D3DXVECTOR3 position;
	// Setup the translation matrix for the cube model.
	for (int i = 0; i < m_Models.size(); i++)
	{
		m_D3D->GetWorldMatrix(worldMatrix);

		position = m_Models.at(i)->pos;
		D3DXMatrixTranslation(&worldMatrix, position.x, position.y, position.z);

		m_Models.at(i)->model->Render(m_D3D->GetDeviceContext());
		result = m_DepthShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
		if (!result)
		{
			return false;
		}
	}

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	m_D3D->SetBackBufferRenderTarget();

	// Reset the viewport back to the original.
	m_D3D->ResetViewport();

	return true;
}

bool GraphicsClass::RenderSceneToTexture5()
{
	D3DXMATRIX worldMatrix, lightViewMatrix, lightProjectionMatrix, translateMatrix;
	float posX, posY, posZ;
	bool result = false;


	// Set the render target to be the render to texture.
	m_RenderTexture5->SetRenderTarget(m_D3D->GetDeviceContext());

	// Clear the render to texture.
	m_RenderTexture5->ClearRenderTarget(m_D3D->GetDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the light view matrix based on the light's position.
	m_Light5->GenerateViewMatrix();

	// Get the world matrix from the d3d object.
	m_D3D->GetWorldMatrix(worldMatrix);

	// Get the view and orthographic matrices from the light object.
	m_Light5->GetViewMatrix(lightViewMatrix);
	m_Light5->GetProjectionMatrix(lightProjectionMatrix);

	D3DXVECTOR3 position;
	// Setup the translation matrix for the cube model.
	for (int i = 0; i < m_Models.size(); i++)
	{
		m_D3D->GetWorldMatrix(worldMatrix);

		position = m_Models.at(i)->pos;
		D3DXMatrixTranslation(&worldMatrix, position.x, position.y, position.z);

		m_Models.at(i)->model->Render(m_D3D->GetDeviceContext());
		result = m_DepthShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
		if (!result)
		{
			return false;
		}
	}

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	m_D3D->SetBackBufferRenderTarget();

	// Reset the viewport back to the original.
	m_D3D->ResetViewport();

	return true;
}


bool GraphicsClass::Render(float rotation)
{
	D3DXMATRIX worldMatrix,worldMatrix5,orthoMatrix, viewMatrix, projectionMatrix, translateMatrix;
	D3DXMATRIX lightViewMatrix, lightProjectionMatrix;
	D3DXMATRIX lightViewMatrix2, lightProjectionMatrix2;
	D3DXMATRIX lightViewMatrix3, lightProjectionMatrix3;
	D3DXMATRIX lightViewMatrix4, lightProjectionMatrix4;
	D3DXMATRIX lightViewMatrix5, lightProjectionMatrix5;
	D3DXMATRIX rotMatrix, translateFan;
	bool result;
	//int mouseX, mouseY;
	float posX, posY, posZ;

	D3DXVECTOR4 diffuseColor[8];
	D3DXVECTOR4 lightPosition[8];

	diffuseColor[0] = g_Light1->GetDiffuseColor(); 
	diffuseColor[1] = g_Light2->GetDiffuseColor(); 
	diffuseColor[2] = g_Light3->GetDiffuseColor(); 
	diffuseColor[3] = g_Light4->GetDiffuseColor(); 
	diffuseColor[4] = g_Light5->GetDiffuseColor();
	diffuseColor[5] = g_Light6->GetDiffuseColor();
	diffuseColor[6] = g_Light7->GetDiffuseColor();
	diffuseColor[7] = g_Light8->GetDiffuseColor();
	// Create the light position array from the four light positions.
	lightPosition[0] = g_Light1->GetPosition2(); 
	lightPosition[1] = g_Light2->GetPosition2(); 
	lightPosition[2] = g_Light3->GetPosition2(); 
	lightPosition[3] = g_Light4->GetPosition2();
	lightPosition[4] = g_Light5->GetPosition2();
	lightPosition[5] = g_Light6->GetPosition2();
	lightPosition[6] = g_Light7->GetPosition2();
	lightPosition[7] = g_Light8->GetPosition2();



	m_D3D->GetWorldMatrix(worldMatrix5);

	// First render the scene to a texture.
	result = RenderSceneToTexture();
	if(!result)
	{
		return false;
	}

	// Render the scene to texture again but use the second light's view point.
	result = RenderSceneToTexture2();
	if(!result)
	{
		return false;
	}

	result = RenderSceneToTexture3();
	if (!result)
	{
		return false;
	}

	result = RenderSceneToTexture4();
	if (!result)
	{
		return false;
	}

	result = RenderSceneToTexture5();
	if (!result)
	{
		return false;
	}

	// Clear the buffers to begin the scene.
	m_D3D->BeginScene(0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_Camera->Render();

	// Generate the light view matrix based on the light's position.
	m_Light->GenerateViewMatrix();

	// Do the same for the second light.
	m_Light2->GenerateViewMatrix();

	m_Light3->GenerateViewMatrix();

	m_Light4->GenerateViewMatrix();

	m_Light5->GenerateViewMatrix();

	// Get the world, view, and projection matrices from the camera and d3d objects.
	m_Camera->GetViewMatrix(viewMatrix);
	m_D3D->GetWorldMatrix(worldMatrix);
	m_D3D->GetProjectionMatrix(projectionMatrix);
	m_D3D->GetOrthoMatrix(orthoMatrix);

	m_key = m_Light->ChangeLights(m_key);

	// Get the light's view and projection matrices from the light object.
	m_Light->GetViewMatrix(lightViewMatrix);
	m_Light->GetProjectionMatrix(lightProjectionMatrix);

	// Do the same for the second light.
	m_Light2->GetViewMatrix(lightViewMatrix2);
	m_Light2->GetProjectionMatrix(lightProjectionMatrix2);

	m_Light3->GetViewMatrix(lightViewMatrix3);
	m_Light3->GetProjectionMatrix(lightProjectionMatrix3);

	m_Light4->GetViewMatrix(lightViewMatrix4);
	m_Light4->GetProjectionMatrix(lightProjectionMatrix4);

	m_Light5->GetViewMatrix(lightViewMatrix5);
	m_Light5->GetProjectionMatrix(lightProjectionMatrix5);

	D3DXMatrixRotationY(&rotMatrix, rotation);
	D3DXMatrixTranslation(&translateFan, -631.287f, 81.635f, -288.184f);

	for (int i = 0; i < m_Models.size(); i++)
	{
		D3DXMatrixIdentity(&worldMatrix);
		// Reset the world matrix.
		m_D3D->GetWorldMatrix(worldMatrix);
		if (m_Models.at(i)->name == "plane" && !m_Models.at(i)->isMoving)
		{
			if (m_Models.at(i)->pos.z > -440)	// end position
				m_Models.at(i)->pos.z -= 1.0f;
			else
				m_Models.at(i)->isMoving = true;
		}
		if (m_Models.at(i)->name == "plane" && m_Models.at(i)->isMoving)
		{
			if (m_Models.at(i)->pos.z < -150) // start position
				m_Models.at(i)->pos.z += 1.0f;
			else
				m_Models.at(i)->isMoving = false;
		}

		// Setup the translation matrix for the cube model.
		D3DXMatrixTranslation(&worldMatrix, m_Models.at(i)->pos.x, m_Models.at(i)->pos.y, m_Models.at(i)->pos.z);

		// Put the model vertex and index buffers on the graphics pipeline to prepare them for drawing.
		m_Models.at(i)->model->Render(m_D3D->GetDeviceContext());

		
		if (m_Models.at(i)->name == "fan")
		{
			worldMatrix = worldMatrix * rotMatrix * translateFan;
		}

		if (m_Models.at(i)->name == "lights" || m_Models.at(i)->name == "screen") {
			result = m_LightShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix, m_Models.at(i)->model->GetTexture(), diffuseColor, lightPosition);
			if (!result)
			{
				return false;
			}
		}
		else {
			// Render the model using the shadow shader.
			result = m_ShadowShader->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix, lightViewMatrix,
				lightProjectionMatrix, m_Models.at(i)->model->GetTexture(), m_RenderTexture->GetShaderResourceView(), m_Light->GetPosition(), m_Light->GetDirection(),
				m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower(), lightViewMatrix2, lightProjectionMatrix2,
				m_RenderTexture2->GetShaderResourceView(), m_Light2->GetPosition(), m_Light2->GetDiffuseColor(), lightViewMatrix3, lightProjectionMatrix3,
				m_RenderTexture3->GetShaderResourceView(), m_Light3->GetPosition(), m_Light3->GetDiffuseColor(), lightViewMatrix4, lightProjectionMatrix4,
				m_RenderTexture4->GetShaderResourceView(), m_Light4->GetPosition(), m_Light4->GetDiffuseColor(), lightViewMatrix5, lightProjectionMatrix5,
				m_RenderTexture5->GetShaderResourceView(), m_Light5->GetPosition(), m_Light5->GetDiffuseColor());
			if (!result)
			{
				return false;
			}
			//����ŧ��
			//result = m_LightShader2->Render(m_D3D->GetDeviceContext(), m_Models.at(i)->model->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix, m_Models.at(i)->model->GetTexture()
			//	, m_Light->GetDirection(), m_Light->GetAmbientColor(), m_Light->GetDiffuseColor(), m_Camera->GetPosition(), m_Light->GetSpecularColor(), m_Light->GetSpecularPower());
			//if (!result)
			//{
			//	return false;
			//}
		}
	}

	m_D3D->TurnZBufferOff();
	m_D3D->TurnOnAlphaBlending();
	result = m_Text->Render(m_D3D->GetDeviceContext(), worldMatrix5, orthoMatrix);
	if (!result)
	{
		return false;
	}

	m_D3D->TurnOffAlphaBlending();
	m_D3D->TurnZBufferOn();


	// Present the rendered scene to the screen.
	m_D3D->EndScene();

	return true;
}

void GraphicsClass::MoveForward()
{
	D3DXMATRIX Dir;
	D3DXMatrixIdentity(&Dir);
	D3DXVECTOR3 Direction(0, 0, 1);
	D3DXMatrixRotationYawPitchRoll(&Dir, CamRot.y * 0.0174532925f, CamRot.x * 0.0174532925f, CamRot.z * 0.0174532925f);
	D3DXVec3TransformCoord(&Direction, &Direction, &Dir);

	CamPos += Direction * speed;
	//ApplyBoundary();

	m_Text->SetPlayerPosition(CamPos.x, CamPos.y, CamPos.z, m_D3D->GetDeviceContext());
}

void GraphicsClass::MoveBack()
{
	D3DXMATRIX Dir;
	D3DXMatrixIdentity(&Dir);
	D3DXVECTOR3 Direction(0, 0, -1);
	D3DXMatrixRotationYawPitchRoll(&Dir, CamRot.y * 0.0174532925f, CamRot.x * 0.0174532925f, CamRot.z * 0.0174532925f);
	D3DXVec3TransformCoord(&Direction, &Direction, &Dir);

	CamPos += Direction * speed;
	//ApplyBoundary();

	m_Text->SetPlayerPosition(CamPos.x, CamPos.y, CamPos.z, m_D3D->GetDeviceContext());
}

void GraphicsClass::MoveLeft()
{
	D3DXMATRIX Dir;
	D3DXMatrixIdentity(&Dir);
	D3DXVECTOR3 Direction(-1, 0, 0);
	D3DXMatrixRotationYawPitchRoll(&Dir, CamRot.y * 0.0174532925f, CamRot.x * 0.0174532925f, CamRot.z * 0.0174532925f);
	D3DXVec3TransformCoord(&Direction, &Direction, &Dir);

	CamPos += Direction * speed;
	//ApplyBoundary();

	m_Text->SetPlayerPosition(CamPos.x, CamPos.y, CamPos.z, m_D3D->GetDeviceContext());
}

void GraphicsClass::MoveRight()
{
	D3DXMATRIX Dir;
	D3DXMatrixIdentity(&Dir);
	D3DXVECTOR3 Direction(1, 0, 0);
	D3DXMatrixRotationYawPitchRoll(&Dir, CamRot.y * 0.0174532925f, CamRot.x * 0.0174532925f, CamRot.z * 0.0174532925f);
	D3DXVec3TransformCoord(&Direction, &Direction, &Dir);

	CamPos += Direction * speed;
	//ApplyBoundary();

	m_Text->SetPlayerPosition(CamPos.x, CamPos.y, CamPos.z, m_D3D->GetDeviceContext());
}

void GraphicsClass::ApplyBoundary()
{
	// y�� ����
	CamPos.y = FixedHeight.y;

	if (CamPos.x > -249)
		isBar = true;
	else
		isBar = false;

	// ���ι� ���
	if (isBar)
	{
#pragma region �� ���� ���
		if (CamPos.x > 149)	// ���̺��� ������ �Ѿ�� ����
			CamPos.x = 149;

		if (CamPos.z > 50 && CamPos.x < 150 && CamPos.x > -155)	// â���� ������ �Ѿ�� ����
			CamPos.z = 50;

		if (CamPos.x > -250 && CamPos.z < -330)	// �������� ������ �Ѿ�� ����
			CamPos.z = -330;

		if (CamPos.x < -130 && CamPos.z > -280)	// �������� ������ �Ѿ�� ����
			CamPos.x = -130;

		if (CamPos.x < -135 && CamPos.x > -250 && CamPos.z > -285)	// ���� + �������� ������ �Ѿ�� ����
			CamPos.z = -285;
#pragma endregion

#pragma region ���̴� ���̺� ���
		if (CamPos.x < 125 && CamPos.x > 35)		// ���ڰ� ���� ��
		{
			if (CamPos.z > -250 && CamPos.z < -200)
				CamPos.z = -250;
			if (CamPos.z < -150 && CamPos.z > -200)
				CamPos.z = -150;

			if (CamPos.z > -90 && CamPos.z < -50)
				CamPos.z = -90;
			if (CamPos.z < -5 && CamPos.z > -50)
				CamPos.z = -5;
		}
		if (CamPos.z > -250 && CamPos.z < -150 ||
			CamPos.z > -90 && CamPos.z < -5)		// ���ڰ� �ִ� ��
		{
			if (CamPos.x < 130 && CamPos.x > 80)
				CamPos.x = 130;
			if (CamPos.x > 30 && CamPos.x < 80)
				CamPos.x = 30;
		}
#pragma endregion

#pragma region �� ���̺� ���
		if (CamPos.x < -20 && CamPos.x > -50 && CamPos.z > -225 && CamPos.z < 35)
			CamPos.x = -20;
		if (CamPos.x > -80 && CamPos.x < -50 && CamPos.z > -225 && CamPos.z < -10)
			CamPos.x = -80;

		if (CamPos.x < -20 && CamPos.x > -85 && CamPos.z > -225 && CamPos.z < -250)
			CamPos.z = -225;
		if (CamPos.x < -60 && CamPos.x > -135 && CamPos.z > -15 && CamPos.z < -10)
			CamPos.z = -15;
		if (CamPos.x < -15 && CamPos.x > -135 && CamPos.z < 35 && CamPos.z > 20)
			CamPos.z = 35;
#pragma endregion
	}

	// ���̳ʸ� ���
	else
	{
#pragma region ���̳ʸ� ���� ���
		if (CamPos.z > 60)
			CamPos.z = 60;

		if (CamPos.z < -645)
			CamPos.z = -645;

		if (CamPos.x > -255 && CamPos.z > -280)
			CamPos.x = -255;

		if (CamPos.x > -255 && CamPos.z < -330)
			CamPos.x = -255;

		if (CamPos.x < -990)
			CamPos.x = -990;
#pragma endregion

#pragma region ���ιٷ� ���
		if ((CamPos.z > -220 && CamPos.z < -70) ||
			(CamPos.z > -520 && CamPos.z < -360)) //�ٷ� �� �� ��� �Ұ�
		{
			if (CamPos.x < -355 && CamPos.x > -400)
				CamPos.x = -355;

			if (CamPos.x > -510 && CamPos.x < -400)
				CamPos.x = -510;

			if (CamPos.x < -550 && CamPos.x > -650)
				CamPos.x = -550;

			if (CamPos.x > -710 && CamPos.x < -600)
				CamPos.x = -710;

			if (CamPos.x < -750 && CamPos.x > -800)
				CamPos.x = -750;

			if (CamPos.x > -900 && CamPos.x < -800)
				CamPos.x = -900;
		}
		if (CamPos.x < -355 && CamPos.x > -510 ||
			CamPos.x < -550 && CamPos.x > -710 ||
			CamPos.x < -750 && CamPos.x > -900)
		{
			if (CamPos.z > -230 && CamPos.z < -150)
				CamPos.z = -230;
			if (CamPos.z < -60 && CamPos.z > -150)
				CamPos.z = -60;

			if (CamPos.z > -530 && CamPos.z < -450)
				CamPos.z = -530;
			if (CamPos.z < -350 && CamPos.z > -450)
				CamPos.z = -350;
		}
#pragma endregion
	}
}


void GraphicsClass::TestIntersection(int mouseX, int mouseY)
{
	float pointX, pointY;
	D3DXMATRIX projectionMatrix, viewMatrix, inverseViewMatrix, worldMatrix, translateMatrix, inverseWorldMatrix;
	D3DXVECTOR3 direction, origin, rayOrigin, rayDirection;
	bool intersect, result;

	// ���콺 ��ǥ�� ������ ���� �࿡�� -1���� +1 ������ �̵��Ͽ� ����
	// ��������� ����Ͽ� ȭ�� �������� ����
	// Move the mouse cursor coordinates into the -1 to +1 range.
	pointX = ((2.0f * (float)mouseX) / (float)m_screenWidth) - 1.0f;
	pointY = (((2.0f * (float)mouseY) / (float)m_screenHeight) - 1.0f) * -1.0f;

	// ����Ʈ�� ��Ⱦ�� �����Ͽ� ���� ��ķ� �� ����
	// Adjust the points using the projection matrix to account for the aspect ratio of the viewport.
	m_D3D->GetProjectionMatrix(projectionMatrix);
	pointX = pointX / projectionMatrix._11;
	pointY = pointY / projectionMatrix._22;

	// �� ��� ���Լ�
	// Get the inverse of the view matrix.
	m_Camera->GetViewMatrix(viewMatrix);
	D3DXMatrixInverse(&inverseViewMatrix, NULL, &viewMatrix);

	// �� ��Ŀ��� ��ŷ���� ���� ���
	// Calculate the direction of the picking ray in view space.
	direction.x = (pointX * inverseViewMatrix._11) + (pointY * inverseViewMatrix._21) + inverseViewMatrix._31;
	direction.y = (pointX * inverseViewMatrix._12) + (pointY * inverseViewMatrix._22) + inverseViewMatrix._32;
	direction.z = (pointX * inverseViewMatrix._13) + (pointY * inverseViewMatrix._23) + inverseViewMatrix._33;


	for (int i = m_Models.size() - 2; i < m_Models.size(); i++)
	{
		// ī�޶��� ��ġ�� picking ray�� ������ ������
		// Get the origin of the picking ray which is the position of the camera.
		origin = m_Camera->GetPosition();

		// ���� ����� ������ ������Ʈ ��ġ�� ��ȯ
		// Get the world matrix and translate to the location of the sphere.
		m_D3D->GetWorldMatrix(worldMatrix);
		D3DXMatrixTranslation(&translateMatrix, m_Models.at(i)->pos.x, m_Models.at(i)->pos.y, m_Models.at(i)->pos.z);
		D3DXMatrixMultiply(&worldMatrix, &worldMatrix, &translateMatrix);

		// ���� ����� ���Լ�
		// Now get the inverse of the translated world matrix.
		D3DXMatrixInverse(&inverseWorldMatrix, NULL, &worldMatrix);

		// ���� ������ ���� ������ �� �������� ���� �������� ��ȯ
		// Now transform the ray origin and the ray direction from view space to world space.
		D3DXVec3TransformCoord(&rayOrigin, &origin, &inverseWorldMatrix);
		D3DXVec3TransformNormal(&rayDirection, &direction, &inverseWorldMatrix);

		// ���� ���� ����ȭ
		// Normalize the ray direction.
		D3DXVec3Normalize(&rayDirection, &rayDirection);

		// �����׽�Ʈ ����
		// Now perform the ray-sphere intersection test.
		intersect = RaySphereIntersect(rayOrigin, rayDirection, 80.0f);

		if (intersect == true)
		{
			// If it does intersect then set the intersection to "yes" in the text string that is displayed to the screen.
			result = m_Text->SetIntersection(true, m_D3D->GetDeviceContext());
			m_Text->SetModelName(m_Models.at(i)->name, m_D3D->GetDeviceContext());
			if (m_Models.at(i)->name == "album") {
				m_Sound->NewSound(m_hwnd);
			}
			break;
		}
		else
		{
			// If not then set the intersection to "No".
			result = m_Text->SetIntersection(false, m_D3D->GetDeviceContext());
		}
	}
	return;
}

bool GraphicsClass::RaySphereIntersect(D3DXVECTOR3 rayOrigin, D3DXVECTOR3 rayDirection, float radius)
{
	float a, b, c, discriminant;

	
	// a, b, c ��� ���
	// Calculate the a, b, and c coefficients.
	a = (rayDirection.x * rayDirection.x) + (rayDirection.y * rayDirection.y) + (rayDirection.z * rayDirection.z);
	b = ((rayDirection.x * rayOrigin.x) + (rayDirection.y * rayOrigin.y) + (rayDirection.z * rayOrigin.z)) * 2.0f;
	c = ((rayOrigin.x * rayOrigin.x) + (rayOrigin.y * rayOrigin.y) + (rayOrigin.z * rayOrigin.z)) - (radius * radius);

	// �����
	// Find the discriminant.
	discriminant = (b * b) - (4 * a * c);

	// ������ ��ŷ ���� ��� | �ƴϸ� ��ŷ ����
	// if discriminant is negative the picking ray missed the sphere, otherwise it intersected the sphere.
	if (discriminant < 0.0f)
	{
		return false;
	}

	return true;
}

bool GraphicsClass::HandleInput()
{
	bool result;
	int mouseX, mouseY;

	// Get the location of the mouse from the input object,
	m_Input->GetMouseLocation(mouseX, mouseY);

	// ����ڰ� ESC ������ �� ����
	if (m_Input->IsEscapePressed() == true)
	{
		return false;
	}

	// ���콺 ���� ��ư�� ���� ������ Ȯ��
	if (m_Input->IsLeftMouseButtonDown() == true)
	{
		// ���콺�� ȭ���� Ŭ�� �� ���� ���� �׽�Ʈ ����
		if (m_beginCheck == false)
		{
			m_beginCheck = true;
			m_Input->GetMouseLocation(mouseX, mouseY);
			TestIntersection(mouseX, mouseY);
		}
	}

	ApplyBoundary();

	// ���� ���콺 ���߰� ���� ������ Ȯ��
	if (m_Input->IsLeftMouseButtonDown() == false)
	{
		m_beginCheck = false;
	}

	if (m_Input->IsWKeyDown())
	{
		MoveForward();
	}
	if (m_Input->IsSKeyDown())
	{
		MoveBack();
	}
	if (m_Input->IsAKeyDown())
	{
		MoveLeft();
	}
	if (m_Input->IsDKeyDown())
	{
		MoveRight();
	}

	if (m_Input->isNum1Down() && !isKeyDown)
	{
		isKeyDown = true;
		m_key = 1;
	}
	if (m_Input->isNum2Down() && !isKeyDown)
	{
		isKeyDown = true;
		m_key = 2;
	}
	if (m_Input->isNum3Down() && !isKeyDown)
	{
		isKeyDown = true;
		m_key = 3;
	}
	if (!m_Input->isNum1Down() && !m_Input->isNum2Down() && !m_Input->isNum3Down())
	{
		isKeyDown = false;
	}

	// Do the input frame processing.
	result = m_Input->Frame();
	if (!result)
	{
		return false;
	}

	return true;
}